# Exaloop Theme

Shared typography, color tokens, and documentation styles for Exaloop sites.
The package contains no application content, private code, or product logos.
It uses the platform's Manrope and IBM Plex Mono typography, blue light-mode
accents, and charcoal/lime dark mode. Fonts are self-hosted through Fontsource;
no Google Fonts request is required.

## Docusaurus

Install the package alongside Docusaurus Classic 3.10 and add the adapter after
the Classic preset:

```js
module.exports = {
  presets: [['classic', {docs: {routeBasePath: '/'}, blog: false}]],
  themes: ['@exaloop/theme/docusaurus'],
};
```

Keep site-specific logos, navigation, content, and styles in the consuming site.
The adapter supplies fonts, tokens, and documentation layout styles. Docusaurus
controls light and dark mode through `data-theme` on the root element.

### Sidebar Icons

Use `withIcon` in your sidebar configuration to add a Lucide icon to a page or
category. Icon names match the kebab-case names in the Lucide catalog:

```js
const {withIcon} = require('@exaloop/theme/sidebar');

module.exports = {
  docs: [
    withIcon('index', 'house'),
    withIcon({type: 'category', label: 'Guides', items: ['start']}, 'book-open'),
  ],
};
```

The helper preserves existing sidebar properties and embeds the SVG in
`customProps.icon`. The adapter renders it as a decorative mask that inherits
the link color, with no external asset request. Icons work in both desktop
and mobile navigation.

## Other Frontends

Import the framework-independent styles into a CSS-aware bundler:

```css
@import '@exaloop/theme/fonts.css';
@import '@exaloop/theme/tokens.css';

body {
  font-family: var(--exaloop-font-sans);
  color: var(--exaloop-text);
  background: var(--exaloop-background);
}
```

Set `data-theme="dark"` to select the dark palette. All tokens use the
`--exaloop-` prefix; importing tokens alone does not restyle application elements.
Plain CSS consumers can copy `styles/tokens.css` without a JavaScript runtime.

## Local Development

Requires Node.js 22 or later. Run `npm ci` and `npm run check` to validate the
package. `npm pack` creates a distributable archive without publishing it.
Codon's docs consume a checked-in archive so CI does not depend on sibling
repositories. After editing this package, run `npm run theme:sync` from
`../codon/website` and rebuild that site. Sync clears the site's bundler cache
so same-version archive updates are included in the next build.

This is an unpublished experiment. Before a public release, select a project
license and review the bundled fonts' upstream license notices. Product logos
remain the responsibility of each consuming application.
