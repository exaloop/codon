import {fileURLToPath} from 'node:url';

export default function exaloopTheme() {
  return {
    name: '@exaloop/theme',
    getThemePath() {
      return fileURLToPath(new URL('./theme/', import.meta.url));
    },
    getClientModules() {
      return ['fonts', 'tokens', 'docusaurus'].map(name =>
        fileURLToPath(new URL(`../styles/${name}.css`, import.meta.url)),
      );
    },
  };
}
