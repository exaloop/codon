import React from 'react';
import DocSidebarItemOriginal from '@theme-init/DocSidebarItem';

export default function DocSidebarItem(props) {
  const icon = props.item.customProps?.icon;
  return React.createElement(DocSidebarItemOriginal, {
    ...props,
    'data-sidebar-icon': icon ? '' : undefined,
    style: {...props.style, '--sidebar-icon': icon},
  });
}
