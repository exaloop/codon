import React from 'react';
import CodeBlock from '@theme/CodeBlock';
import MDXCode from '@theme/MDXComponents/Code';

export default function Pre({children, ...props}) {
  const elements = React.Children.toArray(children);
  const child = elements[0];
  if (elements.length === 1 && React.isValidElement(child)
      && (child.type === MDXCode || child.type === 'code')) {
    return React.createElement(CodeBlock, {...props, ...child.props});
  }
  return React.createElement('pre', props, children);
}
