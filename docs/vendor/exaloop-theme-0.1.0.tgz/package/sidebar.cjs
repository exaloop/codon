const {readFileSync} = require('node:fs');

function withIcon(item, name) {
  if (!/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(name)) {
    throw new TypeError(`Invalid sidebar icon name: ${name}`);
  }
  const entry = typeof item === 'string' ? {type: 'doc', id: item} : item;
  const svg = readFileSync(require.resolve(`lucide-static/icons/${name}.svg`), 'utf8');
  return {...entry, customProps: {...entry.customProps, icon: `url("data:image/svg+xml,${encodeURIComponent(svg)}")`}};
}

module.exports = {withIcon};
